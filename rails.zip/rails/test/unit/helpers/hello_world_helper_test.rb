require 'test_helper'

class HelloWorldHelperTest < ActionView::TestCase
end
