# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ThoraxRails::Application.config.secret_token = '9c9910cef80a91f88b93d24667a56dc4c5320744597b37f2f6278d735917ef4c0a51c4e8f6442a9a27e0822a35f2e58cd11371f15f8180cc8a9be5052a019d72'
