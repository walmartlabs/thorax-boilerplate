Application.View = Thorax.View.extend({

});