Application.Model = Thorax.Model.extend({

});