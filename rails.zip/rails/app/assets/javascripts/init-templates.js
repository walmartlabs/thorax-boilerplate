//handlebars_assets generates the HandlebarsTemplates object
//alias it so Thorax can use it
Thorax.templates = HandlebarsTemplates;