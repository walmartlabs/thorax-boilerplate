Application.View.extend({
  name: "hello-world/index"
});
//this class can be retrieved from:
//Application.Views["hello-world/index"]
