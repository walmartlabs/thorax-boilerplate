Application.Collection = Thorax.Collection.extend({

});