Thorax Standalone Boilerplate
=============================
This example application requires no build system or back end server technology to function. The Node and Rails boilerplate applications provide a mechanism to compile or inline the handlebars templates, here they are simply placed in template script tags on the index.html page. To generate file containing all of your templates install node then run:

    npm install -g thorax
    thorax templates path/to/templates-dir path/to/templates.js

See the [Thorax boilerplate tutorial](https://github.com/walmartlabs/thorax-boilerplate/blob/master/README.md) for more information about the boilerplate projects.
