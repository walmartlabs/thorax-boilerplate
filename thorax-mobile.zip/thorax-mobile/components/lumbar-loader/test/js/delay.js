window.foo = (window.foo || 0) + 1;
