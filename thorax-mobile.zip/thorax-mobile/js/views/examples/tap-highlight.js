Thorax.View.extend({
  name: 'examples/tap-highlight',
  events: {
    'click .test': function() {
      
    }
  }
});
