Thorax.View.extend({
  name: 'examples/infinite-scroll'
});
