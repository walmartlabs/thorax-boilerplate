Application.View.extend({
  name: 'hello-world/index'
});
