Thorax + Lumbar Boilerplate
===========================
This project demonstrates the usage of [Lumbar](http://walmartlabs.github.com/lumbar) as a build system for mobile projects. Lumbar requires Node. Once Node is installed to build and run the application:

    npm start

See the [Thorax boilerplate tutorial](https://github.com/walmartlabs/thorax-boilerplate/blob/master/README.md) for more information about the boilerplate projects.

Todo
----
- Include best practice tap highlight behavior / css styles that will cover both Android and iOS
- Implement infinite scroll example with loading indicator
