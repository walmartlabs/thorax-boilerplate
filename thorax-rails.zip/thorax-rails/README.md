Thorax Rails Boilerplate
========================
This project demonstrates the usage of Thorax with Rails. Ruby and the Rails gem must be installed, then run:

    rails server

See the [Thorax boilerplate tutorial](https://github.com/walmartlabs/thorax-boilerplate/blob/master/README.md) for more information about the boilerplate projects.