require 'test_helper'

class HelloWorldControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
