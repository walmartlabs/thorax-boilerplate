Application.ViewController = Thorax.ViewController.extend({

});