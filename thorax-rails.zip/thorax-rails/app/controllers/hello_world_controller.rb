class HelloWorldController < ApplicationController
  def index
    render :action => "index"
  end
end
