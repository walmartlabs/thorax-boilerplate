(function() {

{{{yield}}}

})();
